@echo off
cd /d "%~dp0"

echo.
echo ==============================================
echo   LOCAL EVENT FINDER - ONE CLICK START
echo ==============================================
echo.

if not exist "venv\Scripts\python.exe" (
    echo Creating Python environment...
    py -m venv venv
)

call "venv\Scripts\activate.bat"

echo Installing required packages...
python -m pip install -r requirements.txt

echo Creating the database...
python -m app.init_db

echo.
echo Application address:
echo http://127.0.0.1:8000
echo.
echo Registration:
echo http://127.0.0.1:8000/register.html
echo.
echo Keep this window open.
echo.

start "" cmd /c "timeout /t 3 /nobreak >nul & start http://127.0.0.1:8000/register.html"

python -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8000

pause
