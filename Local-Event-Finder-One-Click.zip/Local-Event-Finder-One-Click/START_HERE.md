# Local Event Finder — Working Login and Database

This version is designed to run locally without PostgreSQL, DBeaver setup,
a second frontend server, or database passwords.

## Important

The project uses a local SQLite database:

```text
data/local_event_finder.db
```

The database is created automatically when the application starts.

## Information stored after registration

The `users` table stores:

- User ID
- Full name
- Email address
- Secure password hash
- User or admin role
- Account status
- Registration date
- Last successful login date

The password itself is never stored as readable text.

The `login_audits` table stores successful and failed login attempts.

## Easiest start method

Extract the ZIP and double-click:

```text
START_APP.bat
```

Keep the terminal window open.

Open:

```text
Main application:
http://127.0.0.1:8000

Registration:
http://127.0.0.1:8000/register.html

User login:
http://127.0.0.1:8000/user-login.html

Admin login:
http://127.0.0.1:8000/admin-login.html

API documentation:
http://127.0.0.1:8000/docs

Health check:
http://127.0.0.1:8000/health
```

Only one server is required.

## Start from VS Code terminal

Open the extracted project folder in VS Code.

Run:

```powershell
.\START_APP.bat
```

Or:

```powershell
.\START_APP.ps1
```

## Manual start

```powershell
py -m venv venv

.\venv\Scripts\python.exe -m pip install -r requirements.txt

.\venv\Scripts\python.exe -m app.init_db

.\venv\Scripts\python.exe -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

## Create an administrator

Double-click:

```text
CREATE_ADMIN.bat
```

Or run:

```powershell
.\venv\Scripts\python.exe -m app.create_admin `
  --name "Administrator" `
  --email "admin@example.com" `
  --password "ChangeThis123!"
```

## View the database in DBeaver

1. Open DBeaver.
2. Select `Database → New Database Connection`.
3. Select `SQLite`.
4. Choose this file:

```text
data/local_event_finder.db
```

5. Finish the connection.
6. Open:

```text
Tables → users → View Data
```

Login attempts are inside:

```text
Tables → login_audits → View Data
```

## Test the registration flow

1. Open `/register.html`.
2. Enter a new full name, email, and password.
3. Click `Create account`.
4. Open `/user-login.html`.
5. Sign in using the same email and password.
6. The user is redirected to the protected user page.
7. Open DBeaver and refresh the `users` table.

## Reset everything

Stop the server, then delete:

```text
data/local_event_finder.db
```

Start the app again. A clean database will be created automatically.
