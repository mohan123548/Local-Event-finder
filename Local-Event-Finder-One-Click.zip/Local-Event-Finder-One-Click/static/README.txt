LOCAL EVENT FINDER — PRO UI
===========================

A premium, unique, responsive frontend for your Local Event Finder project.

FILES
-----
index.html
styles.css
app.js
assets/*.svg

BACKEND CONNECTION
------------------
The frontend uses:

http://127.0.0.1:8001

Expected endpoints:

GET  /api/events?limit=100
POST /api/events

RUN FASTAPI
-----------
Open PowerShell inside your backend folder:

.\venv\Scripts\python.exe -m uvicorn app.main:app --reload --port 8001

RUN FRONTEND
------------
Open PowerShell inside this frontend folder:

python -m http.server 5501

Or:

py -m http.server 5501

Open:

http://127.0.0.1:5501

IMPORTANT
---------
Use port 5501 so the previous basic frontend on port 5500 does not appear.

After opening the page, press:

Ctrl + Shift + R

FEATURES
--------
- Premium dashboard design
- Unique bento-style hero and city pulse panel
- Search with Ctrl+K shortcut
- Event filtering and sorting
- Grid/list view
- Saved schedule using localStorage
- Detailed event modal
- Add event form connected to FastAPI
- Leaflet map view
- Nearby event distance sorting
- Local event recommendation assistant
- Responsive desktop, tablet and mobile layout
- Dark/light theme
- Bundled SVG artwork
- Demo data when the backend is offline

CACHE-SAFE VERSION
------------------
This build uses styles.v3.css and app.v3.js so Chrome cannot reuse the older
styles.css or app.js from cache.

The event popup is hidden by:
1. HTML hidden attribute
2. Inline display:none fallback
3. Critical inline CSS
4. JavaScript startup reset


AURORA COLOR EDITION
--------------------
This version uses a brighter premium palette:

- Electric cyan
- Neon mint
- Coral accent
- Deep teal background
- More colorful active cards, buttons and navigation

Run on a fresh port such as 5504 to avoid browser cache.
