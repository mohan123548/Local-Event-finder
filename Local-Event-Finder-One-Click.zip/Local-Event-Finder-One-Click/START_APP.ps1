Set-Location $PSScriptRoot

if (-not (Test-Path ".\venv\Scripts\python.exe")) {
    py -m venv venv
}

& ".\venv\Scripts\python.exe" -m pip install -r requirements.txt
& ".\venv\Scripts\python.exe" -m app.init_db

Start-Process "http://127.0.0.1:8000/register.html"

& ".\venv\Scripts\python.exe" -m uvicorn app.main:app `
    --reload `
    --host 127.0.0.1 `
    --port 8000
