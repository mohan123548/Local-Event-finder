from __future__ import annotations

import argparse

from .database import database, init_database, utc_now
from .security import hash_password


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Create or update a Local Event Finder administrator."
    )
    parser.add_argument("--name", required=True)
    parser.add_argument("--email", required=True)
    parser.add_argument("--password", required=True)
    args = parser.parse_args()

    if len(args.password) < 8:
        raise SystemExit("The password must contain at least 8 characters.")

    init_database()

    email = args.email.strip().lower()
    full_name = args.name.strip()

    with database() as connection:
        existing = connection.execute(
            "SELECT id FROM users WHERE email = ? COLLATE NOCASE",
            (email,),
        ).fetchone()

        if existing:
            connection.execute(
                """
                UPDATE users
                SET full_name = ?,
                    password_hash = ?,
                    role = 'admin',
                    is_active = 1
                WHERE id = ?
                """,
                (
                    full_name,
                    hash_password(args.password),
                    existing["id"],
                ),
            )
            action = "updated"
        else:
            connection.execute(
                """
                INSERT INTO users (
                    full_name,
                    email,
                    password_hash,
                    role,
                    is_active,
                    created_at
                )
                VALUES (?, ?, ?, 'admin', 1, ?)
                """,
                (
                    full_name,
                    email,
                    hash_password(args.password),
                    utc_now(),
                ),
            )
            action = "created"

        connection.commit()

    print(f"Administrator {action}: {email}")


if __name__ == "__main__":
    main()
