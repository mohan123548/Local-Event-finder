from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data"
DATABASE_PATH = DATA_DIR / "local_event_finder.db"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def connect() -> sqlite3.Connection:
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    connection = sqlite3.connect(
        DATABASE_PATH,
        timeout=30,
        check_same_thread=False,
    )
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    connection.execute("PRAGMA journal_mode = WAL")

    return connection


@contextmanager
def database() -> Iterator[sqlite3.Connection]:
    connection = connect()

    try:
        yield connection
    finally:
        connection.close()


def init_database() -> None:
    with database() as connection:
        connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                full_name TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE COLLATE NOCASE,
                password_hash TEXT NOT NULL,
                role TEXT NOT NULL DEFAULT 'user'
                    CHECK(role IN ('user', 'admin')),
                is_active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL,
                last_login_at TEXT
            );

            CREATE TABLE IF NOT EXISTS sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                token_hash TEXT NOT NULL UNIQUE,
                created_at TEXT NOT NULL,
                expires_at TEXT NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(id)
                    ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS login_audits (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                email_attempted TEXT NOT NULL,
                role_requested TEXT NOT NULL,
                success INTEGER NOT NULL,
                ip_address TEXT,
                user_agent TEXT,
                failure_reason TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(id)
                    ON DELETE SET NULL
            );

            CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                description TEXT,
                category TEXT,
                city TEXT,
                venue TEXT,
                start_datetime TEXT,
                end_datetime TEXT,
                latitude REAL,
                longitude REAL,
                image_url TEXT,
                source_url TEXT,
                organizer TEXT,
                created_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_users_email
                ON users(email);

            CREATE INDEX IF NOT EXISTS idx_sessions_token
                ON sessions(token_hash);

            CREATE INDEX IF NOT EXISTS idx_login_audits_date
                ON login_audits(created_at DESC);

            CREATE INDEX IF NOT EXISTS idx_events_start
                ON events(start_datetime);
            """
        )
        connection.commit()


def seed_events() -> None:
    demo_events = [
        (
            "Midnight Jazz in the Glasshouse",
            "A cinematic evening of live jazz, candlelight and intimate performances.",
            "Music",
            "Berlin",
            "The Glasshouse",
            "2026-08-02T21:30:00+00:00",
            52.5200,
            13.4050,
            "Nocturne Collective",
            "assets/event-music.svg",
        ),
        (
            "Future Web & AI Summit",
            "A practical technology summit covering FastAPI, JavaScript and AI tools.",
            "Technology",
            "Berlin",
            "Innovation Hub",
            "2026-08-05T09:30:00+00:00",
            52.5310,
            13.3849,
            "Local Developer Network",
            "assets/event-tech.svg",
        ),
        (
            "Green City Community Lab",
            "Meet local residents and learn urban gardening and sustainability.",
            "Community",
            "Berlin",
            "Riverside Garden",
            "2026-08-08T10:00:00+00:00",
            52.5075,
            13.3904,
            "Green City Circle",
            "assets/event-community.svg",
        ),
        (
            "Independent Cinema After Dark",
            "An outdoor screening featuring short films from emerging creators.",
            "Art",
            "Potsdam",
            "Lake View Lawn",
            "2026-08-10T20:30:00+00:00",
            52.3906,
            13.0645,
            "Indie Screen Society",
            "assets/event-art.svg",
        ),
        (
            "Street Food Makers Market",
            "Taste chef-led street food and specialties from independent kitchens.",
            "Food",
            "Berlin",
            "Market Hall Nine",
            "2026-08-12T12:00:00+00:00",
            52.5021,
            13.4316,
            "Berlin Food Makers",
            "assets/event-food.svg",
        ),
    ]

    with database() as connection:
        count = connection.execute(
            "SELECT COUNT(*) AS total FROM events"
        ).fetchone()["total"]

        if count:
            return

        now = utc_now()

        connection.executemany(
            """
            INSERT INTO events (
                title,
                description,
                category,
                city,
                venue,
                start_datetime,
                latitude,
                longitude,
                organizer,
                image_url,
                created_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            [(*event, now) for event in demo_events],
        )
        connection.commit()
