from __future__ import annotations

from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Annotated, Literal

from fastapi import Depends, FastAPI, Header, HTTPException, Query, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, EmailStr, Field

from .database import database, init_database, seed_events, utc_now
from .security import (
    create_session_token,
    hash_password,
    token_hash,
    verify_password,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]
STATIC_DIR = PROJECT_ROOT / "static"


@asynccontextmanager
async def lifespan(_: FastAPI):
    init_database()
    seed_events()
    yield


app = FastAPI(
    title="Local Event Finder",
    description="One-server Local Event Finder with registration and SQLite login storage.",
    version="3.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origin_regex=r"^https?://(127\.0\.0\.1|localhost)(:\d+)?$",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class RegisterRequest(BaseModel):
    full_name: str = Field(min_length=2, max_length=160)
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)


class LoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)


class EventCreate(BaseModel):
    title: str = Field(min_length=2, max_length=200)
    description: str | None = None
    category: str | None = None
    city: str | None = None
    venue: str | None = None
    start_datetime: str | None = None
    end_datetime: str | None = None
    latitude: float | None = None
    longitude: float | None = None
    image_url: str | None = None
    source_url: str | None = None
    organizer: str | None = None


def normalize_email(email: str) -> str:
    return email.strip().lower()


def public_user(row) -> dict:
    return {
        "id": row["id"],
        "full_name": row["full_name"],
        "email": row["email"],
        "role": row["role"],
        "is_active": bool(row["is_active"]),
        "created_at": row["created_at"],
        "last_login_at": row["last_login_at"],
    }


def client_ip(request: Request) -> str | None:
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",")[0].strip()[:64]

    if request.client:
        return request.client.host[:64]

    return None


def write_login_audit(
    connection,
    *,
    request: Request,
    email: str,
    role_requested: str,
    success: bool,
    user_id: int | None = None,
    failure_reason: str | None = None,
) -> None:
    connection.execute(
        """
        INSERT INTO login_audits (
            user_id,
            email_attempted,
            role_requested,
            success,
            ip_address,
            user_agent,
            failure_reason,
            created_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            user_id,
            normalize_email(email),
            role_requested,
            1 if success else 0,
            client_ip(request),
            request.headers.get("user-agent", "")[:1000] or None,
            failure_reason,
            utc_now(),
        ),
    )


def login_for_role(
    *,
    payload: LoginRequest,
    request: Request,
    required_role: Literal["user", "admin"],
) -> dict:
    email = normalize_email(payload.email)

    with database() as connection:
        user = connection.execute(
            "SELECT * FROM users WHERE email = ? COLLATE NOCASE",
            (email,),
        ).fetchone()

        if user is None:
            write_login_audit(
                connection,
                request=request,
                email=email,
                role_requested=required_role,
                success=False,
                failure_reason="Account not found",
            )
            connection.commit()
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Incorrect email address or password.",
            )

        if not verify_password(payload.password, user["password_hash"]):
            write_login_audit(
                connection,
                request=request,
                email=email,
                role_requested=required_role,
                success=False,
                user_id=user["id"],
                failure_reason="Incorrect password",
            )
            connection.commit()
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Incorrect email address or password.",
            )

        if not user["is_active"]:
            write_login_audit(
                connection,
                request=request,
                email=email,
                role_requested=required_role,
                success=False,
                user_id=user["id"],
                failure_reason="Inactive account",
            )
            connection.commit()
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="This account is inactive.",
            )

        if user["role"] != required_role:
            write_login_audit(
                connection,
                request=request,
                email=email,
                role_requested=required_role,
                success=False,
                user_id=user["id"],
                failure_reason=f"Account role is {user['role']}",
            )
            connection.commit()
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"This account does not have {required_role} access.",
            )

        now = datetime.now(timezone.utc)
        expires_at = now + timedelta(days=7)
        raw_token = create_session_token()

        connection.execute(
            "DELETE FROM sessions WHERE user_id = ? OR expires_at <= ?",
            (user["id"], now.isoformat()),
        )
        connection.execute(
            """
            INSERT INTO sessions (
                user_id,
                token_hash,
                created_at,
                expires_at
            )
            VALUES (?, ?, ?, ?)
            """,
            (
                user["id"],
                token_hash(raw_token),
                now.isoformat(),
                expires_at.isoformat(),
            ),
        )
        connection.execute(
            "UPDATE users SET last_login_at = ? WHERE id = ?",
            (now.isoformat(), user["id"]),
        )

        write_login_audit(
            connection,
            request=request,
            email=email,
            role_requested=required_role,
            success=True,
            user_id=user["id"],
        )

        connection.commit()

        updated_user = connection.execute(
            "SELECT * FROM users WHERE id = ?",
            (user["id"],),
        ).fetchone()

    return {
        "access_token": raw_token,
        "token_type": "bearer",
        "user": public_user(updated_user),
    }


def get_current_user(
    authorization: Annotated[str | None, Header()] = None,
) -> dict:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication is required.",
        )

    raw_token = authorization.removeprefix("Bearer ").strip()
    now = datetime.now(timezone.utc).isoformat()

    with database() as connection:
        user = connection.execute(
            """
            SELECT users.*
            FROM sessions
            JOIN users ON users.id = sessions.user_id
            WHERE sessions.token_hash = ?
              AND sessions.expires_at > ?
              AND users.is_active = 1
            """,
            (token_hash(raw_token), now),
        ).fetchone()

    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="The session is invalid or expired.",
        )

    return public_user(user)


def require_admin(
    current_user: Annotated[dict, Depends(get_current_user)],
) -> dict:
    if current_user["role"] != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Administrator access is required.",
        )

    return current_user


@app.get("/health")
def health() -> dict:
    return {
        "status": "ok",
        "database": "sqlite",
        "frontend": "served by FastAPI",
    }


@app.post(
    "/api/auth/register",
    status_code=status.HTTP_201_CREATED,
)
def register(payload: RegisterRequest) -> dict:
    email = normalize_email(payload.email)
    full_name = payload.full_name.strip()

    with database() as connection:
        existing = connection.execute(
            "SELECT id FROM users WHERE email = ? COLLATE NOCASE",
            (email,),
        ).fetchone()

        if existing:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="An account with this email already exists.",
            )

        cursor = connection.execute(
            """
            INSERT INTO users (
                full_name,
                email,
                password_hash,
                role,
                is_active,
                created_at
            )
            VALUES (?, ?, ?, 'user', 1, ?)
            """,
            (
                full_name,
                email,
                hash_password(payload.password),
                utc_now(),
            ),
        )
        connection.commit()

        user = connection.execute(
            "SELECT * FROM users WHERE id = ?",
            (cursor.lastrowid,),
        ).fetchone()

    return public_user(user)


@app.post("/api/auth/user-login")
def user_login(payload: LoginRequest, request: Request) -> dict:
    return login_for_role(
        payload=payload,
        request=request,
        required_role="user",
    )


@app.post("/api/auth/admin-login")
def admin_login(payload: LoginRequest, request: Request) -> dict:
    return login_for_role(
        payload=payload,
        request=request,
        required_role="admin",
    )


@app.get("/api/auth/me")
def me(
    current_user: Annotated[dict, Depends(get_current_user)],
) -> dict:
    return current_user


@app.post("/api/auth/logout", status_code=status.HTTP_204_NO_CONTENT)
def logout(
    authorization: Annotated[str | None, Header()] = None,
) -> None:
    if not authorization or not authorization.startswith("Bearer "):
        return

    raw_token = authorization.removeprefix("Bearer ").strip()

    with database() as connection:
        connection.execute(
            "DELETE FROM sessions WHERE token_hash = ?",
            (token_hash(raw_token),),
        )
        connection.commit()


@app.get("/api/auth/admin/login-history")
def login_history(
    _admin: Annotated[dict, Depends(require_admin)],
    limit: int = Query(default=200, ge=1, le=500),
) -> list[dict]:
    with database() as connection:
        rows = connection.execute(
            """
            SELECT *
            FROM login_audits
            ORDER BY created_at DESC, id DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()

    return [
        {
            **dict(row),
            "success": bool(row["success"]),
        }
        for row in rows
    ]


@app.get("/api/admin/users")
def list_users(
    _admin: Annotated[dict, Depends(require_admin)],
) -> list[dict]:
    with database() as connection:
        rows = connection.execute(
            """
            SELECT *
            FROM users
            ORDER BY created_at DESC, id DESC
            """
        ).fetchall()

    return [public_user(row) for row in rows]


@app.get("/api/events")
def list_events(
    search: str | None = Query(default=None, max_length=100),
    city: str | None = Query(default=None, max_length=120),
    category: str | None = Query(default=None, max_length=100),
    skip: int = Query(default=0, ge=0),
    limit: int = Query(default=100, ge=1, le=200),
) -> dict:
    clauses: list[str] = []
    parameters: list[object] = []

    if search:
        pattern = f"%{search.strip()}%"
        clauses.append(
            """
            (
                title LIKE ?
                OR description LIKE ?
                OR venue LIKE ?
                OR organizer LIKE ?
            )
            """
        )
        parameters.extend([pattern, pattern, pattern, pattern])

    if city:
        clauses.append("city = ? COLLATE NOCASE")
        parameters.append(city.strip())

    if category:
        clauses.append("category = ? COLLATE NOCASE")
        parameters.append(category.strip())

    where_sql = f"WHERE {' AND '.join(clauses)}" if clauses else ""

    with database() as connection:
        total = connection.execute(
            f"SELECT COUNT(*) AS total FROM events {where_sql}",
            parameters,
        ).fetchone()["total"]

        rows = connection.execute(
            f"""
            SELECT *
            FROM events
            {where_sql}
            ORDER BY
                CASE WHEN start_datetime IS NULL THEN 1 ELSE 0 END,
                start_datetime ASC,
                id DESC
            LIMIT ? OFFSET ?
            """,
            [*parameters, limit, skip],
        ).fetchall()

    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "items": [dict(row) for row in rows],
    }


@app.post(
    "/api/events",
    status_code=status.HTTP_201_CREATED,
)
def create_event(
    payload: EventCreate,
    current_user: Annotated[dict, Depends(get_current_user)],
) -> dict:
    values = payload.model_dump()
    organizer = values.get("organizer") or current_user["full_name"]

    with database() as connection:
        cursor = connection.execute(
            """
            INSERT INTO events (
                title,
                description,
                category,
                city,
                venue,
                start_datetime,
                end_datetime,
                latitude,
                longitude,
                image_url,
                source_url,
                organizer,
                created_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                values["title"],
                values.get("description"),
                values.get("category"),
                values.get("city"),
                values.get("venue"),
                values.get("start_datetime"),
                values.get("end_datetime"),
                values.get("latitude"),
                values.get("longitude"),
                values.get("image_url"),
                values.get("source_url"),
                organizer,
                utc_now(),
            ),
        )
        connection.commit()

        event = connection.execute(
            "SELECT * FROM events WHERE id = ?",
            (cursor.lastrowid,),
        ).fetchone()

    return dict(event)


app.mount(
    "/",
    StaticFiles(directory=STATIC_DIR, html=True),
    name="frontend",
)
