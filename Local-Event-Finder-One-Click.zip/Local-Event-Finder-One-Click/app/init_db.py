from .database import DATABASE_PATH, init_database, seed_events


def main() -> None:
    init_database()
    seed_events()

    print("Database created successfully.")
    print(f"Location: {DATABASE_PATH}")
    print("Tables: users, sessions, login_audits, events")


if __name__ == "__main__":
    main()
