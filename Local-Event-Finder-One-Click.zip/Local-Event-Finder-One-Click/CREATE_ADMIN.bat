@echo off
cd /d "%~dp0"

if not exist "venv\Scripts\python.exe" (
    py -m venv venv
)

call "venv\Scripts\activate.bat"
python -m pip install -r requirements.txt

set /p ADMIN_NAME=Administrator name: 
set /p ADMIN_EMAIL=Administrator email: 
set /p ADMIN_PASSWORD=Administrator password: 

python -m app.create_admin --name "%ADMIN_NAME%" --email "%ADMIN_EMAIL%" --password "%ADMIN_PASSWORD%"

pause
